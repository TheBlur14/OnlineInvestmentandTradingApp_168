package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelBookingsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelBookingsiteApplication.class, args);
	}

}
